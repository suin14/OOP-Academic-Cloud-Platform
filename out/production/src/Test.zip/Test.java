import Sys.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws FileNotFoundException {
//        File inputFile = new File("input.txt"); Scanner scan = new Scanner(inputFile);
        Scanner scan = new Scanner(System.in);
        String input;
        Sys system = new Sys();

        while (true) {
            input = scan.nextLine().trim();
            if (input.isEmpty()) {
                continue;
            }
            String[] tokens = input.split("\\s+");
            String command = tokens[0];
            String[] params = getParameters(tokens);

            try {

                if (command.equals("quit")) {
                    if (!validateParamCount(params, 0)) {
                        System.out.println(Feedback.ILLEGAL_ARGUMENT_COUNT);
                    } else {
                        system.quit();
                        return;
                    }
                } else if (command.equals("register")) {
                    if (!validateParamCount(params, 5)) {
                        System.out.println(Feedback.ILLEGAL_ARGUMENT_COUNT);
                    } else {
                        system.register(params);
                    }
                } else if (command.equals("login")) {
                    if (!validateParamCount(params, 2)) {
                        System.out.println(Feedback.ILLEGAL_ARGUMENT_COUNT);
                    } else {
                        system.login(params);
                    }
                } else if (command.equals("logout")) {
                    if (params.length > 1) {
                        System.out.println(Feedback.ILLEGAL_ARGUMENT_COUNT);
                    } else {
                        system.logout(params);
                    }
                } else if (command.equals("printInfo")) {
                    if (params.length > 1) {
                        System.out.println(Feedback.ILLEGAL_ARGUMENT_COUNT);
                    } else {
                        system.printInfo(params);
                    }
                } else if (command.equals("createCourse")) {
                    if (!validateParamCount(params, 4)) {
                        System.out.println(Feedback.ILLEGAL_ARGUMENT_COUNT);
                    } else {
                        system.createCourse(params);
                    }
                } else if (command.equals("listCourse")) {
                    if (params.length > 1) {
                        System.out.println(Feedback.ILLEGAL_ARGUMENT_COUNT);
                    } else {
                        system.listCourse(params);
                    }
                } else if (command.equals("selectCourse")) {
                    if (!validateParamCount(params, 1)) {
                        System.out.println(Feedback.ILLEGAL_ARGUMENT_COUNT);
                    } else {
                        system.selectCourse(params);
                    }
                } else if (command.equals("cancelCourse")) {
                    if (!validateParamCount(params, 1)) {
                        System.out.println(Feedback.ILLEGAL_ARGUMENT_COUNT);
                    } else {
                        system.cancelCourse(params);
                    }
                } else {
                    System.out.println("Command '" + command + "' not found");
                }
            } catch (IllegalArgumentException e) {
                System.out.println(input);
            }
        }
    }

    private static String[] getParameters(String[] tokens) {
        return tokens.length > 1 ? Arrays.copyOfRange(tokens, 1, tokens.length) : new String[0];
    }

    private static boolean validateParamCount(String[] params, int expectedCount) {
        if (params.length != expectedCount) {
            System.out.println(Feedback.ILLEGAL_ARGUMENT_COUNT);
            return false;
        }
        return true;
    }

}
